create table users(
       user_id number not null primary key ,
       user_name varchar2(10) not null unique,
       user_passwork varchar2(15) not null,
       type number(2) check(type in(1,2)) 
);
create sequence seq_users_userid
start with 1;

create table book(
       book_id number not null primary key,
       book_name varchar2(20) not null ,
       book_count number not null,
       status number(2) check(status in(0,1))
       
);
create sequence seq_book_bookid
start with 1;

create table record(
       record_id number not null primary key ,
       user_id number not null ,
       book_id number not null ,
       lend_time date not null,
       return_time date   
);
create sequence seq_record_recordid
start with 1;

alter table record add constraint record_userid_fx foreign key(user_id) references users(user_id);
alter table record add constraint record_bookid_fx foreign key(book_id) references book(book_id);
