package com.neuedu.library.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 封装连接数据库的相应操作：
 * getConnection方法
 * close方法
 *
 */
public class DBUtils {
	
	private static String driverName;
	private static String url;
	private static String userName;
	private static String password;
	
	static{
		//因为操作属性文件，所以java语言提供了专门的类来做这件事
		Properties p=new Properties();
		try {
			p.load(new FileInputStream(new File("config\\db.properties")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		driverName=p.getProperty("driverName");
		url=p.getProperty("url");
		userName=p.getProperty("userName");
		password=p.getProperty("password");
		
	}
	
	public static Connection getConnection()
	{
		Connection conn=null;
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url, userName, password);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

}
