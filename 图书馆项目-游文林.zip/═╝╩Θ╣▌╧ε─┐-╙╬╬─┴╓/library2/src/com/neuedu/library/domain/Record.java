package com.neuedu.library.domain;

import java.util.Date;

public class Record {
	private Integer record_id;
	/** 关联对象属性 */
	private int  user_id;
	private int  book_id;
	private Date lend_time;
	private Date return_time;
	public int getBook_id() {
		return book_id;
	}

	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	@Override
	public String toString() {
		return "Record [record_id=" + record_id + ", user_id=" + user_id + ", book_id=" + book_id + ", lend_time="
				+ lend_time + ", return_time=" + return_time + "]";
	}

	public Record(Integer record_id, int user_id, int book_id, Date lend_time, Date return_time) {
		super();
		this.record_id = record_id;
		this.user_id = user_id;
		this.book_id = book_id;
		this.lend_time = lend_time;
		this.return_time = return_time;
	}

	public Record() {
		super();
		// TODO 自动生成的构造函数存根
	}

	public Integer getRecord_id() {
		return record_id;
	}

	public void setRecord_id(Integer record_id) {
		this.record_id = record_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public Date getLend_time() {
		return lend_time;
	}

	public void setLend_time(Date lend_time) {
		this.lend_time = lend_time;
	}

	public Date getReturn_time() {
		return return_time;
	}

	public void setReturn_time(Date return_time) {
		this.return_time = return_time;
	}
	
	

}
