package com.neuedu.library.dao.impl;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class BaseDao {

	private static String driverName;
	private static String url;
	private static String userName;
	private static String password;

	static {
		// 因为操作属性文件，所以java语言提供了专门的类来做这件事
		Properties p = new Properties();
		try {
			p.load(new FileReader("config\\db.properties"));

		} catch (IOException e) {
			e.printStackTrace();
		}
		// 从属性文件中读取到的参数信息
		driverName = p.getProperty("driverName");
		url = p.getProperty("url");
		userName = p.getProperty("userName");
		password = p.getProperty("password");
		// 加载驱动，放在静态初始化块中，只执行一次
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	public static void close(Connection conn, Statement stmt, ResultSet rs) {
		if (rs != null)
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if (stmt != null)
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if (conn != null)
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

	/**
	 * 封装更新操作（add,update,delete）
	 */
	public boolean actionUpdate(String sql, List<Object> params) {
		Connection conn = null;
		PreparedStatement stmt = null;
		int rows = 0;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			// 给sql语句中的占位符赋值
			if (params != null) {
				// 集合中有几个参数，那么for循环就执行几次
				for (int i = 0; i < params.size(); i++) {
					stmt.setObject(i + 1, params.get(i));
				}
			}
			rows = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, stmt, null);
		}
		return rows > 0 ? true : false;
	}

	public <T> List<T> actionQuery(String sql, List<Object> params, Class<T> cls) {
		// 声明返回值
		List<Object> list = new ArrayList<>();
		// 声明访问数据库的三大对象
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);

			// 如果sql语句有占位符，那么params集合中必定有参数值，那么使用stmt对象的方法给占位符赋值
			if (params != null) {
				for (int i = 0; i < params.size(); i++) {
					stmt.setObject(i + 1, params.get(i));
				}
			}
			rs = stmt.executeQuery();
			// 获取元数据,最终目的是想获取对应类中定义的属性名称
			ResultSetMetaData md = rs.getMetaData();// 其实是结果集中的列名：book_id
													// book_name book_count
													// status
			// 获取结果集中的列数
			int columnCount = md.getColumnCount();
			System.out.println("列数：" + columnCount);
			/*
			 * 接下来的主要功能是：把数据从rs对象中拿出来放到list集合中
			 */
			while (rs.next()) {
				// 根据传过来的实参cls可以实例化一个对象
				Object obj = cls.newInstance();
				/*
				 * 今天给对象的属性赋值，使用的技术是反射：拿到该属性book_name的方法setBook_name对象method,
				 * 那么可以使用method.invoke()来调用方法
				 */
				// 由于有多少个列，所以要拿属性拿多少次
				for (int i = 0; i < columnCount; i++) {
					// 获取元数据中第一列的列名
					String columnName = md.getColumnName(i + 1);// BOOK_ID
					String fieldName = columnName.toLowerCase();// book_id

					// 我们希望根据属性名得到该属性所对应的赋值方法
					String methodName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);// setbook_id
					System.out.println("methodName:" + methodName);
					// 得到属性对应的数据类型,注意希望获取私有属性，那么使用getDeclaredField(fieldName)方法
					Class type = cls.getDeclaredField(fieldName).getType();
					System.out.println("type:" + type.getName());
					Method method = cls.getDeclaredMethod(methodName, type);

					// 根据属性的数据类型决定调用哪种方法赋值
					// 该方法比较调用对象和参数指定对象是否是同一类
					if (type.isAssignableFrom(boolean.class) || type.isAssignableFrom(Boolean.class)) {
						method.invoke(obj, rs.getBoolean(i + 1));
					} else if (type.isAssignableFrom(int.class) || type.isAssignableFrom(Integer.class)) {
						method.invoke(obj, rs.getInt(i + 1));
					} else if (type.isAssignableFrom(String.class)) {
						method.invoke(obj, rs.getString(i + 1));
					} else if (type.isAssignableFrom(Date.class)) {
						method.invoke(obj, rs.getDate(i + 1));
					}
				}

				list.add(obj);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(conn, stmt, rs);
		}

		return (List<T>) list;
	}

}