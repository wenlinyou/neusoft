package com.neuedu.library.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.neuedu.library.dao.ifac.UsersDao;
import com.neuedu.library.domain.Users;

public class UsersDaoImpl extends BaseDao implements UsersDao {

	private static final String QUERY_ALL_USERS = "select user_id,user_name,user_password,type from users";
	private static final String QUERY_USER_BY_USERNAME_AND_PASSWORD="select user_id,user_name,user_password,type from users"
			+ " where user_name=? and user_password=?";
	private static final String QUERY_USER_BY_USERNAME = "select user_id,user_name,user_password,type from users"
			+ " where user_name=?";
	private static final String SAVE_USERS = "insert into users(user_id,user_name,user_password,type) values"
			+ "(seq_users_userid.nextval,?,?,1)";
	private static final String DELETE_USERS = "delete from USERS where user_id=?";

	@Override
	public List<Users> queryAllUsers() {
		
		return actionQuery(QUERY_ALL_USERS,null,Users.class);
	}

	@Override
	public Users queryUserByUsernameAndPassword(String userName, String password) {
		List<Object> params=new ArrayList<>();
		params.add(userName);
		params.add(password);
		List<Users> list=actionQuery(QUERY_USER_BY_USERNAME_AND_PASSWORD, params, Users.class);
		//list集合中没有元素，那么调用get(0)也会报错，所以这样写
		if(list.size()==0)
		{
			return null;
		}
		return list.get(0);
	}

	@Override
	public Users queryUserByUsername(String userName) {
		List<Object> params=new ArrayList<>();
		params.add(userName);
		List<Users> list=actionQuery(QUERY_USER_BY_USERNAME, params, Users.class);
		//list集合中没有元素，那么调用get(0)也会报错，所以这样写
		if(list.size()==0)
		{
			return null;
		}
		return list.get(0);
	}

	@Override
	public boolean saveUsers(Users user) {
		List<Object> params=new ArrayList<>();
		params.add(user.getUser_name());
		params.add(user.getUser_password());
		
		return actionUpdate(SAVE_USERS, params);
	}

	@Override
	public boolean deleteUsersById(int user_id) {
		List<Object> params=new ArrayList<>();
		params.add(user_id);
		return actionUpdate(DELETE_USERS, params);
	}


}
