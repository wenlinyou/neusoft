package com.neuedu.library.dao.ifac;

import java.util.List;

import com.neuedu.library.domain.Book;

/**
 * 访问book表的dao:数据访问对象--dao（data access object）
 *
 */
public interface BookDao {
	
	public boolean addBook(Book book);
	public boolean updateBook(Book book);
	public boolean deleteBookById(int book_id);
	public boolean lendBook(int user_id,int book_id);
	
	public Book queryBookById(int book_id);
	public List<Book> queryBookByName(String book_name);
	/**查找热门图书，根据借阅次数对书籍进行排序，然后取前5名*/
	public List<Book> queryHotBook();
	public List<Book> queryAllBooks();
	/** 查询所有可借图书 */
	public List<Book> queryCanLendBook();
	/** 查询所有不可借图书 */
	public List<Book> queryNotLendBook();
	
	
	
	/** 修改图书的借阅次数 */
	public boolean updateBookCount(Book book);
	/** 修改图书的状态 */
	public boolean updateBookStatus(Book book);
	
	

}
