package com.neuedu.library.dao.ifac;

import java.util.List;

import com.neuedu.library.domain.Users;

public interface UsersDao {
	
	public List<Users> queryAllUsers();
	
	public Users queryUserByUsernameAndPassword(String userName,String password);
	
	public Users queryUserByUsername(String userName);
	
	public boolean saveUsers(Users user);
	
	public boolean deleteUsersById(int user_id);
}
