package com.neuedu.library.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neuedu.library.dao.ifac.BookDao;
import com.neuedu.library.domain.Book;

public class BookDaoImpl extends BaseDao implements BookDao {

	private static final String ADD_BOOK = "insert into book(book_id,book_name,book_count,status) "
											+ "values(seq_book_bookid.nextval,?,0,1)";
	private static final String UPDATE_BOOK = "update book set book_name=?,book_count=?,status=? where book_id=?";
	private static final String DELETE_BOOK = "delete from book where book_id=?";
	private static final String QUERY_ALL_BOOKS = "select book_id,book_name,book_count,status from book";
	private static final String QUERY_HOT_BOOK = " select b2.book_id,b2.book_name,b2.book_count,b2.status "+
			  "from "+
			  "(select b.*,rownum "+
			  "from "+
			 " (select book_id,book_name,book_count,status from book order by book_count desc) b "+
			 " where rownum<6) b2";
	private static final String QUERY_CAN_LEND_BOOK = "select book_id,book_name,book_count,status from book where status=1";
	private static final String QUERY_NOT_CAN_LEND_BOOK = "select book_id,book_name,book_count,status from book where status=0";

	
	@Override
	public boolean addBook(Book book) {
		List<Object> params=new ArrayList<>();
		params.add(book.getBook_name());
		return actionUpdate(ADD_BOOK, params);
	}

	@Override
	public boolean updateBook(Book book) {
		List<Object> params=new ArrayList<>();
		params.add(book.getBook_name());
		params.add(book.getBook_count());
		params.add(book.getStatus());
		params.add(book.getBook_id());
		
		return actionUpdate(UPDATE_BOOK, params);
	}

	@Override
	public boolean deleteBookById(int book_id) {
		List<Object> params=new ArrayList<>();
		params.add(book_id);
		
		return actionUpdate(DELETE_BOOK, params);
	}

	@Override
	public Book queryBookById(int book_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> queryBookByName(String book_name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> queryHotBook() {
		List<Book> list=actionQuery(QUERY_HOT_BOOK,null,Book.class);
		return list;
	}

	@Override
	public List<Book> queryAllBooks() {
		List<Book> list=actionQuery(QUERY_ALL_BOOKS,null,Book.class);
		return list;
	}

	@Override
	public List<Book> queryCanLendBook() {
		List<Book> list=actionQuery(QUERY_CAN_LEND_BOOK,null,Book.class);
		return list;
	}

	@Override
	public List<Book> queryNotLendBook() {
		List<Book> list=actionQuery(QUERY_NOT_CAN_LEND_BOOK,null,Book.class);
		return list;
	}

	@Override
	public boolean updateBookCount(Book book) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateBookStatus(Book book) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean lendBook(int user_id, int book_id) {
		/* 1.再次查询书籍是否可借
		 * 2.更新书的状态（不可借）和借阅次数（加1）
		 * 3.向借书记录表中添加数据，一条借书信息
		 */
		boolean tmp=false;
		Connection conn=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		try{
			conn=getConnection();
			conn.setAutoCommit(false);
			stmt=conn.prepareStatement("select * from book where book_id="+book_id+" and status=1");
			rs=stmt.executeQuery();
			if(rs.next())
			{
				stmt=conn.prepareStatement("update book set book_count=book_count+1,status=0 where book_id="+book_id);
				int rows1=stmt.executeUpdate();
				stmt=conn.prepareStatement("insert into record (record_id,user_id,book_id,lend_time,return_time) "
						+ "values (seq_record_recordid.nextval,"+user_id+","+book_id+",sysdate,null)");
				int rows2=stmt.executeUpdate();
				
				if(rows1>0&&rows2>0)
				{
					conn.commit();
					tmp=true;
				}else
				{
					conn.rollback();
				}
			}
		}catch(Exception e)
		{
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally
		{
			close(conn, stmt, rs);
		}
		
		return tmp;
	}


	
	
	

}
