package com.neuedu.library.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.neuedu.library.dao.ifac.RecordDao;
import com.neuedu.library.domain.Record;

public class RecordDaoImpl extends BaseDao implements RecordDao {

	public static void main(String[] args) {
		// RecordDaoImpl dao=new RecordDaoImpl();
		// dao.deleteRecordById(42);

	}

	private static final String ADD_Record = "insert into record(record_id,user,book,lend_time,return_time) "
			+ "values(seq_book_bookid.nextval,?,seq_book_bookid.nextval,seq_book_bookid.nextval,seq_book_bookid.nextval)";
	private static final String DELETE_RECORD = "delete from RECORD where record_id=?";
	// private static final String QUERY_RECORD = "update book status=1 where
	// book_id=?";
	private static final String QUERY_RECORD = "select * from record where return_time is null";

	@Override
	public boolean addRecord(Record record) {
		List<Object> params = new ArrayList<>();
//		params.add(record.getUser());
		return actionUpdate(ADD_Record, params);
	}

	@Override
	public boolean updateRecord(Record record) {
		// TODO 自动生成的方法存根
		return false;
	}

	@Override
	public boolean deleteRecordById(int record_id) {
		List<Object> params = new ArrayList<>();
		params.add(record_id);
		return actionUpdate(DELETE_RECORD, params);
	}

	@Override
	public List<Record> queryRecordBook() {
		
		return actionQuery(QUERY_RECORD, null, Record.class);
	}

}
