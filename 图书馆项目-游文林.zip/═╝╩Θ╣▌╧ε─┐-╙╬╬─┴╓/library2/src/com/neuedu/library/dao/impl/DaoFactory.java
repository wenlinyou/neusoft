package com.neuedu.library.dao.impl;

import com.neuedu.library.dao.ifac.BookDao;
import com.neuedu.library.dao.ifac.RecordDao;
import com.neuedu.library.dao.ifac.UsersDao;

/**
 * dao工厂：专门生产dao层的实例
 *
 */
public class DaoFactory {
	

	public static UsersDao getInstanceOfUsersDao()
	{
		return new UsersDaoImpl();
	}

	public static BookDao getInstanceOfBookDao() 
	{
		return new BookDaoImpl();
	}
	
	public static RecordDao getInstanceOfRecordDao() 
	{
		return new RecordDaoImpl();
	}


}
