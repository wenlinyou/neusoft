package com.neuedu.library.dao.ifac;

import java.util.List;

import com.neuedu.library.domain.Record;

public interface RecordDao {
	//增加记录
	public boolean addRecord(Record record);
	//修改记录
	public boolean updateRecord(Record record);
	//根据记录id删除记录
	public boolean deleteRecordById(int record_id);
	//查询已借书籍
	public List<Record> queryRecordBook();
	
}
