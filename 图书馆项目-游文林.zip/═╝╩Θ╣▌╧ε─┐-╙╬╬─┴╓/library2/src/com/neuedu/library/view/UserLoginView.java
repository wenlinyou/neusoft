package com.neuedu.library.view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.neuedu.library.domain.Users;
import com.neuedu.library.service.ifac.UsersService;
import com.neuedu.library.service.impl.ServiceFactory;

public class UserLoginView extends JFrame{
	
	private JPanel commom_panel;
	private JPanel panel_left;
	private JPanel panel_right;
	private JLabel label_image;
	
	private JLabel label_username;
	private JLabel label_password;
	private JLabel label_type;

	private JTextField text_username;
	private JTextField text_password;
	private JComboBox<String> text_type;
	
	private JButton btn_login;
	private JButton btn_register;
	
	private JLabel kong1;
	private JLabel kong2;
	
	//用作把各个组件初始化的方法
	private void init(){
		commom_panel=new JPanel(new GridLayout(1, 2));
		panel_left=new JPanel(new GridLayout(1, 1));
		panel_right=new JPanel(new GridLayout(6,2 ));
		
		label_username=new JLabel("用户名：");
		label_password=new JLabel("密    码：");
		label_type=new JLabel("类    型：");
		
		text_username=new JTextField();
		text_password=new JTextField();
		text_type=new JComboBox<String>(new String[]{"管理员","用户"});
		
		btn_login=new JButton("登陆");
		btn_register=new JButton("注册");
		
		 kong1=new JLabel("图书管理系统");
		 kong2=new JLabel();
	
		Icon image=new ImageIcon("config/图片/linyuner.jpg");
		label_image=new JLabel(image);
		panel_left.add(label_image);
		commom_panel.add(panel_left);
		this.add(commom_panel);
		
		
		panel_right.add(kong1);
		panel_right.add(kong2);
		panel_right.add(label_username);
		panel_right.add(text_username);
		panel_right.add(label_password);
		panel_right.add(text_password);
		panel_right.add(label_type);
		panel_right.add(text_type);
		panel_right.add(btn_login);
		panel_right.add(btn_register);
		commom_panel.add(panel_right);
		registerListener();
		
	}

	public UserLoginView(String title){
		init();
		this.setTitle(title);
		this.setSize(500, 280);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	/**
	 * 给登陆按钮，注册按钮添加监听器 
	 * 
	 */
	private void registerListener()
	{
		btn_login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("你 点击 登陆按钮了");
				/*
				 * 1.获取用户名，密码，用户类型
				 *  非空判断，为空，提醒用户输入
				 *  		不为空，执行第2步
				 * 2.拿着用户名和密码去数据库查询用户是否存在
				 * 	存在登陆成功去到主界面
				 * 	不存在提示用户，用户名密码错误，重新输入
				 */
				//1.获取用户名，密码，用户类型
				String username=text_username.getText().trim();
				String password=text_password.getText().trim();
				String type=(String)text_type.getSelectedItem();
				System.out.println(username+","+password+","+type);
				//2.做非空判断
				if("".equals(username))
				{
					JOptionPane.showMessageDialog(UserLoginView.this, "请输入用户名");
					return;
				}
				if("".equals(password))
				{
					JOptionPane.showMessageDialog(UserLoginView.this, "请输入密码");
					return;
				}
				UsersService service=ServiceFactory.getInstanceOfUsersService();
				Users user=service.login(username, password);
				
				if(user==null)
				{
					JOptionPane.showMessageDialog(UserLoginView.this, "用户名密码错误");
					return;
				}else
				{
					// 如果用户合法：根据用户类型，跳转到对应窗体
					if(user.getType()==1)
					{
						// 普通用户
						UsersMainView umf=new UsersMainView(user);
						System.out.println("普通用户");
					}else
					{
						//等于2是管理员
						AdminMainView amf=new AdminMainView();
						System.out.println("管理员");
					}
				}
			}
		});
		btn_register.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("你点击注册按钮了");
				new UserRegisterView("注册窗体");
				//销毁当前的登陆窗体
				UserLoginView.this.dispose();
			}
		});
	}
	
	public static void main(String[] args) {
		UserLoginView u = new UserLoginView("图书馆管理系统");
	}

}

