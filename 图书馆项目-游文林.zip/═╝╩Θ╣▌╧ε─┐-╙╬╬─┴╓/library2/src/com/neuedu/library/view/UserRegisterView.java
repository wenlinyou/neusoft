package com.neuedu.library.view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.neuedu.library.domain.Users;
import com.neuedu.library.service.ifac.UsersService;
import com.neuedu.library.service.impl.ServiceFactory;
/**
 * 用户注册窗体，
 * 创建窗体的思路：
 * 一个主面板   panel_main
 * 5个子面板
 * 1.panel1  ---null
 * 2.panel2  ---lb_username 用户名标签  tf_username用户名输入框
 * 3.panel3  ---lb_password         tf_password
 * 4.panel4  ---lb_confirm_password tf_confirm_password
 * 5.panel5  ---btn_submit          btn_exit
 */
public class UserRegisterView extends JFrame{
//	容器属性
	private JPanel panel_main;
	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;
	private JPanel panel5;
	
//	组件属性
	private JLabel lb_username;
	private JLabel lb_password;
	private JLabel lb_confirm_password;
	
	private JTextField tf_username;
	private JTextField tf_password;
	private JTextField tf_confirm_password;
	
	private JButton btn_submit;
	private JButton btn_exit;
	
	private void init()
	{
		panel_main=new JPanel(new GridLayout(5,1));
		panel1=new JPanel(new GridLayout(1, 2));
		panel2=new JPanel(new GridLayout(1, 2));
		panel3=new JPanel(new GridLayout(1, 2));
		panel4=new JPanel(new GridLayout(1, 2));
		panel5=new JPanel(new GridLayout(1, 2));
		
		lb_username=new JLabel("用户名：",JLabel.RIGHT);
		lb_password=new JLabel("密    码：",JLabel.RIGHT);
		lb_confirm_password=new JLabel("确认密码：",JLabel.RIGHT);
		
		tf_username=new JTextField(20);
		tf_password=new JTextField(20);
		tf_confirm_password=new JTextField(20);
		
		btn_submit=new JButton("提交");
		btn_exit=new JButton("退出");
		
		panel1.add(new JLabel());
		panel2.add(lb_username);
		panel2.add(tf_username);
		
		panel3.add(lb_password);
		panel3.add(tf_password);
		
		panel4.add(lb_confirm_password);
		panel4.add(tf_confirm_password);
		
		panel5.add(btn_submit);
		panel5.add(btn_exit);
		
		panel_main.add(panel1);
		panel_main.add(panel2);
		panel_main.add(panel3);
		panel_main.add(panel4);
		panel_main.add(panel5);
		
		this.add(panel_main);
		//调用注册监听器的方法
		registerListener();
	}
	
	private void registerListener(){
		btn_submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				/*
				 * 1.获取数据，非空判断，为空返回
				 * 2.判断密码和确认密码是否一致
				 * 3.判断用户名是否已经使用，已经使用返回并提示用户
				 * 4.将数据保存到数据库，注意：service和dao要有对应的处理方法
				 * 5.注册可能失败，各种情况
				 */
				//1.获取数据，非空判断，为空返回
				String username=tf_username.getText().trim();
				String password=tf_password.getText().trim();
				String confirm_password=tf_confirm_password.getText().trim();
				if("".equals(username))
				{
					JOptionPane.showMessageDialog(UserRegisterView.this, "请输入用户名");
					return;
				}
				if("".equals(password))
				{
					JOptionPane.showMessageDialog(UserRegisterView.this, "请输入密码");
					return;
				}
				if("".equals(confirm_password))
				{
					JOptionPane.showMessageDialog(UserRegisterView.this, "请输入确认密码");
					return;
				}
				//2.判断密码和确认密码是否一致
				if(!password.equals(confirm_password))
				{
					JOptionPane.showMessageDialog(UserRegisterView.this, "两次输入密码不一致");
					return;
				}
				//3.判断用户名是否已经使用，已经使用返回并提示用户
				UsersService service=ServiceFactory.getInstanceOfUsersService();
				if(!service.queryNameIsUsed(username))
				{
					//把用户名和密码封装到user对象中
					Users user=new Users(username, password);
					//保存到数据库
					Boolean result=service.saveUsers(user);
					if(result)
					{
						//销毁当前注册窗体
						UserRegisterView.this.dispose();
						new UserLoginView("登陆窗体");
					}else
					{
						JOptionPane.showMessageDialog(UserRegisterView.this, "请重新注册");
						return;
					}
				}else
				{
					JOptionPane.showMessageDialog(UserRegisterView.this, "用户名已被占用，请重新注册");
					return;
				}
				
			}
		});
		
		btn_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				UserRegisterView.this.disable();
			}
		});
		
	}
	public UserRegisterView (String title){
		init();
		this.setTitle(title);
		this.setSize(400,200);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setVisible(true);
	}

}
