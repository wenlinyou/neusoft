package com.neuedu.library.view;

	import java.awt.BorderLayout;
	import java.awt.GridLayout;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.awt.event.MouseEvent;
	import java.awt.event.MouseListener;
	import java.util.List;

	import javax.swing.JButton;
	import javax.swing.JInternalFrame;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
	import javax.swing.JPanel;
	import javax.swing.JScrollPane;
	import javax.swing.JTable;
	import javax.swing.event.TableModelListener;
	import javax.swing.table.TableModel;

	import com.neuedu.library.domain.Record;
	import com.neuedu.library.domain.Users;
	import com.neuedu.library.service.ifac.BookService;
	import com.neuedu.library.service.ifac.RecordService;
	import com.neuedu.library.service.impl.ServiceFactory;

	public class UserQueryRecordView extends JInternalFrame {

		private JPanel panel_main;
		private JScrollPane panel_left;
		private JPanel panel_right;

		// 存放数据的表格控件
		private JTable table;


		private JButton btn_return;
		private JButton btn_query;
		private JButton btn_exit;

		// 定义一个成员变量，用于存放用户想要借阅的图书编号信息
		private int book_id;
		// 定义当前窗口所以来的属性service
		BookService service = ServiceFactory.getInstanceOfBookService();
		RecordService reservice = ServiceFactory.getInstanceOfRecordService();
		// 定义用户属性user
		private Users user;

		public UserQueryRecordView(Users user) {
			this.user = user;
		}

		// 初始化
		private void init() {
			panel_main = new JPanel(new BorderLayout());
			table = new JTable();
			panel_left = new JScrollPane(table);
			panel_right = new JPanel(new GridLayout(7, 1, 0, 20));
		

			btn_exit = new JButton("退出窗口");
			btn_return = new JButton("还书");
			btn_query = new JButton("查询已借");

			
			panel_right.add(btn_query);
			panel_right.add(btn_return);
			panel_right.add(new JLabel());
			panel_right.add(new JLabel());
			panel_right.add(new JLabel());
			panel_right.add(new JLabel());
			panel_right.add(btn_exit);

			panel_main.add(panel_left, BorderLayout.CENTER);
			panel_main.add(panel_right, BorderLayout.EAST);

			this.add(panel_main);
		}

		{
			init();
			this.setSize(600, 500);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setIconifiable(true);
			this.setVisible(true);
			this.setClosable(true);
			this.UserQueryRecordListener();
		}

		private void UserQueryRecordListener() {
			// TODO 自动生成的方法存根
			btn_exit.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO 自动生成的方法存根
					UserQueryRecordView.this.dispose();
				}
			});

			btn_return.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
//				
				
					
				
				}
			});

			btn_query.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {

					List<Record> list = null;
					RecordService service = ServiceFactory
							.getInstanceOfRecordService();
					list = service.queryRecordBook();
					BookDataModel bd = new BookDataModel();
					bd.setList(list);
					table.setModel(bd);
				}
			});

			table.addMouseListener(new MouseListener() {

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO 自动生成的方法存根

				}

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO 自动生成的方法存根

				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO 自动生成的方法存根

				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO 自动生成的方法存根

				}

				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO 自动生成的方法存根
					int row = table.getSelectedRow();
					System.out.println(row);
					book_id = (Integer) table.getValueAt(row, 0);
				}
			});
		}

		private class BookDataModel implements TableModel {

			/** 将要显示的数据放在集合中 */
			private List<Record> list;

			public void setList(List<Record> list) {
				this.list = list;
			}

			/** 行数 */
			@Override
			public int getRowCount() {
				// TODO 自动生成的方法存根
				return list.size();
			}

			/** 列数 */
			@Override
			public int getColumnCount() {
				// TODO 自动生成的方法存根
				return 2;
			}

			/** 列名 */
			@Override
			public String getColumnName(int columnIndex) {
				if (columnIndex == 0) {
					return "图书编号";
				} else if (columnIndex == 1) {
					return "借阅时间";
				} else {
					return "出错";
				}
			}

			/** 全部数据以字符串形式显示 */
			@Override
			public Class<?> getColumnClass(int columnIndex) {
				// TODO 自动生成的方法存根
				return String.class;
			}

			@Override
			public boolean isCellEditable(int rowIndex, int columnIndex) {
				// TODO 自动生成的方法存根
				return false;
			}

			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				Record record = list.get(rowIndex);
				if (columnIndex == 0) {
					return record.getBook_id();
				} else if (columnIndex == 1) {
					return record.getLend_time();
				} else {
					return "出错";
				}
			}

			@Override
			public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
				// TODO 自动生成的方法存根

			}

			@Override
			public void addTableModelListener(TableModelListener l) {
				// TODO 自动生成的方法存根

			}

			@Override
			public void removeTableModelListener(TableModelListener l) {
				// TODO 自动生成的方法存根

			}

		}
	} 


