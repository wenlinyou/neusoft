package com.neuedu.library.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import com.neuedu.library.domain.Book;
import com.neuedu.library.domain.Users;
import com.neuedu.library.service.ifac.BookService;
import com.neuedu.library.service.impl.ServiceFactory;
/**
 * 用户查询图书窗体，不能单独显示，是一个嵌入式窗体
 * 结构分析：一个主面版  两个子面板（表格数据存放的面板， 按钮组面板）
 * 组件：
 * 表格组件
 * 滚动面板组件
 * 一个标签
 * 一个下拉框
 * 三个按钮：查询，借书，退出窗口
 */
public class UserQueryBookView extends JInternalFrame {
	
	private JPanel panel_main;
	private JScrollPane panel_left;
	private JPanel panel_right;
	
	//存放数据的表格控件
	private JTable table;
	
	private JLabel lb_type;
	private JComboBox<String> cb_query_type;
	private JButton btn_query;
	private JButton btn_lend;
	private JButton btn_exit;
	
	//定义一个成员变量，用于存放用户想要借阅的图书编号信息
	private int book_id;
	//定义当前窗体所依赖的属性service
	BookService service=ServiceFactory.getInstanceOfBookService();
	//定义用户属性user
	private Users user;
	public UserQueryBookView(Users user) {
		this.user=user;
	}


	//初始化方法
	private void init(){
		panel_main=new JPanel(new BorderLayout());
		table=new JTable();
		panel_left=new JScrollPane(table);
		panel_right=new JPanel(new GridLayout(7,1,0,20));
		//设置panel的边框，有浮雕效果
		panel_right.setBorder(BorderFactory.createTitledBorder(BorderFactory.createRaisedBevelBorder(), "查询条件"));
		
		lb_type=new JLabel("查询类型");
		cb_query_type=new JComboBox<String>(new String[]{"全部书籍","热门图书","可借图书","不可借图书"});
		
		btn_exit=new JButton("退出窗口");
		btn_lend=new JButton("借书");
		btn_query=new JButton("查询");
		
		//组装
		panel_right.add(lb_type);
		panel_right.add(cb_query_type);
		panel_right.add(btn_query);
		panel_right.add(btn_lend);
		panel_right.add(new JLabel());
		panel_right.add(new JLabel());
		panel_right.add(btn_exit);
		
		panel_main.add(panel_left,BorderLayout.CENTER);
		panel_main.add(panel_right,BorderLayout.EAST);
		
		this.add(panel_main);
	}
	
	{
		init();
		this.setSize(600, 500);
		//设置窗体可以关闭
		this.setClosable(true);
		//设置默认的关闭操作，隐藏但不释放内存空间
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		//窗体能否最小化
		this.setIconifiable(true);
		this.setVisible(true);
		registerListener();
	}
	//给三个按钮注册监听器
	private void registerListener() 
	{
		btn_query.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				/* 1.获取下拉框用户选定的查询类型
				 * 2.调用底层service的方法执行查询，并获取结果
				 * 
				 */
				//1.获取下拉框用户选定的查询类型
				int query_type=cb_query_type.getSelectedIndex();
				System.out.println(query_type);
				//2.调用底层service的方法执行查询，并获取结果
				List<Book> list=null;
				BookService service=ServiceFactory.getInstanceOfBookService();
				if(query_type==0)
				{
					list=service.queryAll();
				}else if(query_type==1)
				{
					list=service.queryHotBook();
				}else if(query_type==2)
				{
					list=service.queryCanLendBook();
				}else if(query_type==3)
				{
					list=service.queryNotCanLendBook();
				}
				//3.将结果显示在窗体上
				BookDataModel dm=new BookDataModel();
				dm.setList(list);
				table.setModel(dm);
				
				
			}
		});
		
		table.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				int row=table.getSelectedRow();
				System.out.println(row);
				book_id=(Integer)table.getValueAt(row, 0);
				System.out.println("book_id:"+book_id);
				System.out.println(user.getUser_id());
			}
		});
		
		btn_lend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/* 1.首先获取用户选定的图书
				 * 2.调用service中的借书方法完成借书功能
				 */
				boolean result=service.lendBook(user.getUser_id(), book_id);
				if(result)
				{
					JOptionPane.showMessageDialog(null, "借书成功");
					
				}else
				{
					JOptionPane.showMessageDialog(null, "借书失败");
				}
			}
		});
		
		btn_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				UserQueryBookView.this.dispose();
				
			}
		});
		
		
		
	} 
	
	/**
	 * 创建数据模型：定义一个内部类实现
	 */
	private class BookDataModel implements TableModel
	{
		/**1.显示什么数据？*/
		private List<Book> list;
		//解决赋值问题
		public void setList(List<Book> list)
		{
			this.list=list;
		}
		
		@Override/** 显示多少行  */
		public int getRowCount() {
			return list.size();
		}

		@Override/** 显示多少列  */
		public int getColumnCount() {
			return 4;
		}

		@Override/** 显示的列的每一列的列名  */
		public String getColumnName(int columnIndex) {//列索引从0开始，
			if(columnIndex==0)
			{
				return "图书编号";
			}else if(columnIndex==1)
			{
				return "图书名称";
			}else if(columnIndex==2)
			{
				return "借阅次数";
			}else if(columnIndex==3)
			{
				return "是否可借";
			}else
			{
				return "出错";
			}
		}

		@Override/**全部数据以字符串形式显示*/
		public Class<?> getColumnClass(int columnIndex) {
			return String.class;
		}

		@Override
		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return false;
		}

		@Override/**表格的每个单元格如果想有数据，那么会调用这个方法获取数据        */
		public Object getValueAt(int rowIndex, int columnIndex) 
		{
			Book book=list.get(rowIndex);
			if(columnIndex==0)
			{
				return book.getBook_id();
			}else if(columnIndex==1)
			{
				return book.getBook_name();
			}else if(columnIndex==2)
			{
				return book.getBook_count();
			}else if(columnIndex==3)
			{
				return book.getStatus()==0?"不可借":"可借";
			}else
			{
				return "出错";
			}
		}

		@Override
		public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		}

		@Override
		public void addTableModelListener(TableModelListener l) {
		}

		@Override
		public void removeTableModelListener(TableModelListener l) {
		}
		
	}
	
}
