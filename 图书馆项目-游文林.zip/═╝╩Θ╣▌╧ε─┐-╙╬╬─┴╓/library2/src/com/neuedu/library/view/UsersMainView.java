package com.neuedu.library.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
///
// 用户登陆之后的主界面： 界面的结构：分成三大部分: 
// 1.顶部：滚动文字效果---欢迎张三使用图书借阅管理系统 标签lb_welcome
// 2.左面板:显示子窗体 图片标签 lb_img 
// 3.右面板:按钮组面板
// 图书查询按钮：btn_query_book,图书借阅记录查询:btn_query_record,退出窗口按钮：btn_exit

import com.neuedu.library.domain.Users;

public class UsersMainView extends JFrame {

	private JPanel panel_main;
	private JPanel panel_welcome;
	// 定义成桌面面板，便于叠放多个嵌入窗体
	private JDesktopPane panel_left;
	private JPanel panel_right;

	private JLabel lb_welcome;
	private JLabel lb_img;

	private JButton btn_query_book;
	private JButton btn_query_record;
	private JButton btn_exit;

	// 定义user属性
	private Users user;

	public UsersMainView(Users user) {
		this.user = user;
		init();
	}

	private void init() {
		panel_main = new JPanel(new BorderLayout());
		panel_welcome = new JPanel();
		panel_left = new JDesktopPane();
		panel_right = new JPanel(new GridLayout(7, 1, 0, 30));

		lb_welcome = new JLabel();
		lb_welcome.setText("欢  迎  " + user.getUser_name() + "使  用  图  书  借  阅  管  理  系  统");
		lb_img = new JLabel(new ImageIcon("config\\图片\\tushu.jpg"));
		lb_img.setBounds(0, 0, 600, 600);

		btn_query_book = new JButton("图书查询");
		btn_query_record = new JButton("图书借阅记录查询");
		btn_exit = new JButton("退出窗口");

		// 组装
		panel_welcome.add(lb_welcome);
		panel_left.add(lb_img);
		panel_right.add(new JLabel());
		panel_right.add(new JLabel());
		panel_right.add(btn_query_book);
		panel_right.add(btn_query_record);
		panel_right.add(btn_exit);
		panel_right.add(new JLabel());
		panel_right.add(new JLabel());
		// 将三个面包添加至主窗体
		panel_main.add(panel_welcome, BorderLayout.NORTH);
		panel_main.add(panel_left, BorderLayout.CENTER);
		panel_main.add(panel_right, BorderLayout.EAST);

		registerListener();

		this.add(panel_main);

		// 窗体初始化
		// 窗体大小
		this.setSize(800, 600);
		// 窗体不可以放大
		this.setResizable(false);
		// 窗体居中
		this.setLocationRelativeTo(null);
		// true表示显示窗体
		this.setVisible(true);
	}

	/**
	 * 给按钮注册事件监听器
	 */
	private void registerListener() {
		btn_query_book.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				UserQueryBookView uqbv = new UserQueryBookView(user);
				panel_left.add(uqbv);
				// 因为支持叠放，所以让窗体显示到最前面
				uqbv.toFront();
			}
		});
		btn_query_record.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				UserQueryRecordView uqrv=new UserQueryRecordView(user);
				panel_left.add(uqrv);
				// 因为支持叠放，所以让窗体显示到最前面
				uqrv.toFront();
				 
				
			}
		});
		btn_exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				UsersMainView.this.dispose();

			}
		});
	}

	
}
