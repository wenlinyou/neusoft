package com.neuedu.library.service.impl;

import com.neuedu.library.service.ifac.BookService;
import com.neuedu.library.service.ifac.RecordService;
import com.neuedu.library.service.ifac.UsersService;

/**
 * service工厂：专门生产service层的实例
 *
 */
public class ServiceFactory {
	
	public static  UsersService getInstanceOfUsersService()
	{
		return new UsersServiceImpl();
	}

	public static BookService getInstanceOfBookService() 
	{
		return new BookServiceImpl();
	}

	public static RecordService getInstanceOfRecordService() {
		
		return new RecordServiceImpl();
	}
	
	
	

}
