package com.neuedu.library.service.impl;

import java.util.List;

import com.neuedu.library.dao.ifac.RecordDao;
import com.neuedu.library.dao.impl.DaoFactory;
import com.neuedu.library.domain.Record;
import com.neuedu.library.service.ifac.RecordService;

public class RecordServiceImpl implements RecordService {

	private RecordDao rdao = DaoFactory.getInstanceOfRecordDao();
	@Override
	public boolean recordBook(int book_id) {
		// TODO 自动生成的方法存根
		return false;
	}

	@Override
	public List<Record> queryRecordBook() {
		// TODO 自动生成的方法存根
		return rdao.queryRecordBook();
	}

}
