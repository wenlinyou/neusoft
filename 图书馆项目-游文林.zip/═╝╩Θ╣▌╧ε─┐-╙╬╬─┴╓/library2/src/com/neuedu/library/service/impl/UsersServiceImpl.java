package com.neuedu.library.service.impl;

import com.neuedu.library.dao.ifac.UsersDao;
import com.neuedu.library.dao.impl.DaoFactory;
import com.neuedu.library.domain.Users;
import com.neuedu.library.service.ifac.UsersService;

public class UsersServiceImpl implements UsersService {
	
	//真正访问数据库的对象是dao
	//private UsersDaoImpl dao=new UsersDaoImpl();  不利于层与层之间解耦合
	private UsersDao dao=DaoFactory.getInstanceOfUsersDao();

	@Override
	public Users login(String userName, String password) {
		Users user=dao.queryUserByUsernameAndPassword(userName,password);
		return user;
	}

	@Override
	public boolean queryNameIsUsed(String username) {
		Users user=dao.queryUserByUsername(username);
		return user==null?false:true;
	}

	@Override
	public boolean saveUsers(Users user) {
		return dao.saveUsers(user);
	}

}
