package com.neuedu.library.service.ifac;

import com.neuedu.library.domain.Users;

/**
 * 用户模块的业务接口
 *
 */
public interface UsersService {
	
	/** 处理登陆的方法 */
	public Users login(String userName,String password);
	
	/** 查看用户名是否已经被占用的方法 
	 * @return:   true:已经被占用  false:未使用
	 *  */
	public boolean queryNameIsUsed(String username);
	
	/**
	 * 处理注册的方法：保存用户信息到数据库
	 */
	public boolean saveUsers(Users user);

}
