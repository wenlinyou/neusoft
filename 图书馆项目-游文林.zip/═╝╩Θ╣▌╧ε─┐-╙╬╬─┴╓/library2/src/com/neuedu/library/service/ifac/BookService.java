package com.neuedu.library.service.ifac;

import java.util.List;

import com.neuedu.library.domain.Book;

public interface BookService {
	
	/**
	 * 定义一堆查询方法
	 */
	
	public List<Book> queryAll();
	public List<Book> queryHotBook();
	public List<Book> queryCanLendBook();
	public List<Book> queryNotCanLendBook();

	/**
	 * 借书方法
	 */
	public boolean lendBook(int user_id,int book_id);
}
