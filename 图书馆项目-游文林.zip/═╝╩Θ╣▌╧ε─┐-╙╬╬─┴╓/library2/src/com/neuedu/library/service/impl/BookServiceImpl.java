package com.neuedu.library.service.impl;

import java.util.List;

import com.neuedu.library.dao.ifac.BookDao;
import com.neuedu.library.dao.impl.DaoFactory;
import com.neuedu.library.domain.Book;
import com.neuedu.library.service.ifac.BookService;

public class BookServiceImpl implements BookService {
	
	private BookDao dao=DaoFactory.getInstanceOfBookDao();

	@Override
	public List<Book> queryAll() {
		return dao.queryAllBooks();
	}

	@Override
	public List<Book> queryHotBook() {
		return dao.queryHotBook();
	}

	@Override
	public List<Book> queryCanLendBook() {
		return dao.queryCanLendBook();
	}

	@Override
	public List<Book> queryNotCanLendBook() {
		return dao.queryNotLendBook();
	}

	@Override
	public boolean lendBook(int user_id, int book_id) {
		return dao.lendBook(user_id, book_id);
	}

}
