package com.neuedu.library.service.ifac;

import java.util.List;

import com.neuedu.library.domain.Record;

public interface RecordService {

	boolean recordBook(int book_id);

	List<Record> queryRecordBook();
	
}
