package testReflect;

public class Student {
	private int id;
}
