package com.neuedu.library.util;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.Test;

import com.neuedu.library.dao.impl.BaseDao;

public class DBUtilsTest {

	@Test
	public void testGetConnection() {
		Connection conn=BaseDao.getConnection();
		assertNotNull(conn);
	}

}
