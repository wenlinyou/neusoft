package com.neuedu.library.view;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserLoginViewTest {

	@Test
	public void testUserLoginView() {
		UserLoginView loginView=new UserLoginView("图书馆管理系统");
		while(loginView.isVisible())
		{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
