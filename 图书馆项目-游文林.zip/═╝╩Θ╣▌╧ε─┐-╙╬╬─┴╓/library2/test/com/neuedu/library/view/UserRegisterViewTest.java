package com.neuedu.library.view;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserRegisterViewTest {

	@Test
	public void testUserRegisterView() {
		fail("尚未实现");
	}

}
