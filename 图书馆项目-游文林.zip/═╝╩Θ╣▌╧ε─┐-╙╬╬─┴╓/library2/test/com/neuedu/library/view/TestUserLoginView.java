package com.neuedu.library.view;

import static org.junit.Assert.*;

import org.junit.Test;


public class TestUserLoginView {

	@Test
	public void testAdd() {
		UserLoginView frame=null;
		assertNotNull(frame);
	}
	
	@Test
	public void testJian() {
		UserLoginView frame=new UserLoginView("我的第一个窗体");
		while(frame.isVisible())
		{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	@Test
	public void testCheng() {
		UserLoginView frame=new UserLoginView("我的第一个窗体");
	}
	public static void main(String[] args) {
		UserLoginView frame=new UserLoginView("我的第一个窗体");
	}
}
