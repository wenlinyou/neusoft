package com.neuedu.library.dao.impl;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;

import com.neuedu.library.domain.Book;

public class BookDaoImplTest {

	@Test
	public void testAddBook() {
		BookDaoImpl dao=new BookDaoImpl();
		Book book=new Book();
		book.setBook_name("三毛流浪记");
		boolean tmp=dao.addBook(book);
		assertTrue(tmp);
		}

	@Test
	public void testUpdateBook() {
		BookDaoImpl dao=new BookDaoImpl();
		Book book=new Book(11, "西厢记", 0, 1);
		boolean tmp=dao.updateBook(book);
		assertTrue(tmp);
	}

	@Test
	public void testDeleteBookById() {
		BookDaoImpl dao=new BookDaoImpl();
		assertTrue(dao.deleteBookById(3));
	}
	@Test
	public void testQueryBookById() {
		fail("Not yet implemented");
	}

	@Test
	public void testQueryBookByName() {
		fail("Not yet implemented");
	}

	@Test
	public void testQueryHotBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testQueryAllBooks() {
		BookDaoImpl dao=new BookDaoImpl();
		List<Book> list=dao.queryAllBooks();
		for(Book b:list)
		{
			System.out.println(b);
		}
	}

	@Test
	public void testQueryCanLendBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testQueryNotLendBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateBookCount() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateBookStatus() {
		fail("Not yet implemented");
	}

}
