package com.neuedu.library.dao.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.neuedu.library.domain.Users;

public class UsersDaoImplTest 
{

	@Test
	public void testQueryAllUsers()
	{
		UsersDaoImpl dao=new UsersDaoImpl();
		List<Users> list=dao.queryAllUsers();
		for(Users u:list)
		{
			System.out.println(u);
		}
	}
	@Test
	public void testDeleteUsersById() {
		UsersDaoImpl dao=new UsersDaoImpl();
		assertTrue(dao.deleteUsersById(7));
	}
}
